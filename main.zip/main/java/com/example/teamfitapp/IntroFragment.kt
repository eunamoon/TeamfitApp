package com.example.teamfitapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView

class IntroFragment : Fragment() {

    companion object {
        fun newInstance(nickname: String): IntroFragment {
            val fragment = IntroFragment()
            val args = Bundle()
            args.putString("nickname", nickname)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_intro, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val nickname = arguments?.getString("nickname") ?: "회원"
        val nicknameText = view.findViewById<TextView>(R.id.nicknameText)
        val startButton = view.findViewById<ImageButton>(R.id.startButton)

        nicknameText.text = "잘 맞는 팀원을 만나기 위해\n${nickname}님의 키워드를 알아봐요 :-)"

        startButton.setOnClickListener {
            (activity as? QuestionActivity)?.moveToFirstQuestion()
        }
    }
}
