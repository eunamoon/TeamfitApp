package com.example.teamfitapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignUpActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var sendEmailButton: ImageButton
    private lateinit var verifyCheckButton: ImageButton
    private lateinit var nextButton: ImageButton

    private var isEmailVerified = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val backTextView = findViewById<TextView>(R.id.backTextView)
        backTextView.setOnClickListener {
            finish() // 이 액티비티 종료 → 이전 화면으로
        }

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        nameEditText = findViewById(R.id.nameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        phoneEditText = findViewById(R.id.phoneEditText)
        sendEmailButton = findViewById(R.id.sendVerificationEmailButton)
        verifyCheckButton = findViewById(R.id.verifyCheckButton)
        nextButton = findViewById(R.id.nextButton)

        nextButton.isEnabled = false

        sendEmailButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString()

            sendEmailButton.setBackgroundResource(R.drawable.emailverifi_done)

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "이메일과 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        auth.currentUser?.sendEmailVerification()
                            ?.addOnCompleteListener { verifiTask ->
                                if (verifiTask.isSuccessful) {
                                    Toast.makeText(this, "인증 메일을 보냈습니다. 이메일을 확인해주세요.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(this, "인증 메일 전송 실패: ${verifiTask.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                    } else {
                        val msg = task.exception?.message ?: "회원 생성 실패"
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                }
        }

        verifyCheckButton.setOnClickListener {
            val user = auth.currentUser
            user?.reload()?.addOnSuccessListener {
                if (user.isEmailVerified) {
                    if (!isEmailVerified) {
                        isEmailVerified = true
                        verifyCheckButton.setBackgroundResource(R.drawable.emailconfirm_done) // 인증 후에만 이미지 변경
                        Toast.makeText(this, "✅ 이메일 인증이 완료되었습니다!", Toast.LENGTH_SHORT).show()
                        checkInputConditions()
                    } else {
                        Toast.makeText(this, "이미 인증된 상태입니다.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "❗ 아직 이메일 인증을 하지 않았습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        //다음 버튼 클릭 시
        nextButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val phone = phoneEditText.text.toString().trim()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()

            //이메일 인증이 완료되지 않았을 때
            if (!isEmailVerified) {
                Toast.makeText(this, "이메일 인증을 완료해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //모든 필드가 입력되지 않았을 때
            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "모든 필드를 입력해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //비밀번호랑 비밀번호 확인창이 일치하지 않을 때
            if (password != confirmPassword) {
                Toast.makeText(this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val uid = auth.currentUser?.uid ?: return@setOnClickListener

            val userData = hashMapOf(
                "name" to name,
                "email" to email,
                "phone" to phone
            )
            // firestore에 저장
            firestore.collection("users")
                .document(uid)
                .set(userData)
                .addOnSuccessListener {
                    Toast.makeText(this, "회원가입 성공!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, ProfileActivity::class.java))
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "회원 정보 저장 실패", Toast.LENGTH_SHORT).show()
                }
        }

        setupInputWatchers()
    }

    //입력 상태 wathcer
    private fun setupInputWatchers() {
        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                checkInputConditions()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }

        nameEditText.addTextChangedListener(watcher)
        emailEditText.addTextChangedListener(watcher)
        passwordEditText.addTextChangedListener(watcher)
        confirmPasswordEditText.addTextChangedListener(watcher)
        phoneEditText.addTextChangedListener(watcher)

        updateNextButtonState()

    }

    //입력한 상태 확인
    private fun checkInputConditions() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val pw = passwordEditText.text.toString()
        val confirmPw = confirmPasswordEditText.text.toString()
        val phone = phoneEditText.text.toString().trim()

        nextButton.isEnabled =
                name.isNotEmpty() &&
                email.isNotEmpty() &&
                pw.isNotEmpty() &&
                confirmPw.isNotEmpty() &&
                phone.isNotEmpty()

        updateNextButtonState()

    }

    //다음 버튼 활성화
    private fun updateNextButtonState() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val pw = passwordEditText.text.toString()
        val confirmPw = confirmPasswordEditText.text.toString()
        val phone = phoneEditText.text.toString().trim()

        val isReady =
                name.isNotEmpty() &&
                email.isNotEmpty() &&
                pw.isNotEmpty() &&
                confirmPw.isNotEmpty() &&
                phone.isNotEmpty()

        nextButton.isEnabled = isReady
        nextButton.setBackgroundResource(
            if (isReady) R.drawable.btnnext else R.drawable.btnnextdisable
        )
    }

}