package com.example.teamfitapp

import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class JobBottomSheet(
    private val onSelected: (List<String>) -> Unit
) : BottomSheetDialogFragment() {

    private var selectedTag: String? = null
    private var selectedEditText: EditText? = null
    private val elseMap = mutableMapOf<String, EditText>() // group → EditText
    private val allRadioButtons = mutableListOf<RadioButton>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val root = inflater.inflate(R.layout.fragment_job_botton_sheet, container, false)
        val containerLayout = root.findViewById<LinearLayout>(R.id.jobContainer)

        val jobMap = mapOf(
            "개발" to listOf("프론트엔드", "백엔드", "모바일", "풀스택", "기타(직접입력)"),
            "디자인" to listOf("UI/UX 디자이너", "그래픽/시각 디자이너", "기타(직접입력)"),
            "기획" to listOf("서비스 기획자", "프로젝트 매니저", "마케터", "운영 매니저", "기타(직접입력)")
        )

        jobMap.forEach { (group, items) ->
            val groupLabel = TextView(requireContext()).apply {
                text = group
                setTypeface(null, Typeface.BOLD)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(0, 24, 0, 12)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val arrowIcon = ImageView(requireContext()).apply {
                setImageResource(R.drawable.iconbottom)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val headerLayout = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                addView(groupLabel)
                addView(arrowIcon)
            }

            val subLayout = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            headerLayout.setOnClickListener {
                val isVisible = subLayout.visibility == View.VISIBLE
                subLayout.visibility = if (isVisible) View.GONE else View.VISIBLE
                arrowIcon.setImageResource(if (isVisible) R.drawable.iconbottom else R.drawable.icontop)
            }

            items.forEach { item ->
                val radioButton = RadioButton(requireContext()).apply {
                    text = item
                    setPadding(8, 16, 8, 16)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    buttonDrawable = null
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.iconuncheck, 0, 0, 0)

                    setOnClickListener {
                        // 모든 라디오 버튼 해제
                        allRadioButtons.forEach {
                            it.setTypeface(null, Typeface.NORMAL)
                            it.setCompoundDrawablesWithIntrinsicBounds(R.drawable.iconuncheck, 0, 0, 0)
                            it.isChecked = false
                        }

                        selectedTag = item
                        selectedEditText?.visibility = View.GONE
                        selectedEditText?.text?.clear()

                        setTypeface(null, Typeface.BOLD)
                        setCompoundDrawablesWithIntrinsicBounds(R.drawable.iconcheck, 0, 0, 0)
                        isChecked = true

                        if (item.contains("기타")) {
                            elseMap[group]?.visibility = View.VISIBLE
                            selectedEditText = elseMap[group]
                        }
                    }
                }

                allRadioButtons.add(radioButton)
                subLayout.addView(radioButton)

                if (item.contains("기타")) {
                    val input = EditText(requireContext()).apply {
                        hint = "$group 항목 직접 입력"
                        visibility = View.GONE
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = 8
                        }
                    }
                    subLayout.addView(input)
                    elseMap[group] = input
                }
            }

            containerLayout.addView(headerLayout)
            containerLayout.addView(subLayout)
        }

        root.findViewById<ImageButton>(R.id.confirmBtn).setOnClickListener {
            val result = mutableListOf<String>()

            selectedTag?.let {
                if (it.contains("기타")) {
                    val custom = selectedEditText?.text?.toString()?.trim().orEmpty()
                    if (custom.isNotEmpty()) {
                        result.add(custom)
                    }else{}
                } else {
                    result.add(it)
                }
            }

            onSelected(result)
            dismiss()
        }

        return root
    }
}