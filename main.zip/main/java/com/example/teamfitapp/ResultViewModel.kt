package com.example.teamfitapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.firestore

class ResultViewModel : ViewModel() {
    var userResult by mutableStateOf(UserResult())
        private set

    init {
        fetchUserResult()
    }

    private fun fetchUserResult() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        Firebase.firestore.collection("users").document(uid)
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    userResult = document.toObject(UserResult::class.java) ?: UserResult()
                }
            }
    }

}