package com.example.teamfitapp

data class UserResult(
    val nickname: String = "",
    val intro: String = "",
    val keywords: List<String> = emptyList()
)
