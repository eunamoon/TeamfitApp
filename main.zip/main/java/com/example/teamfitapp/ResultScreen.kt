package com.example.teamfitapp

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ResultScreen(
    viewModel: ResultViewModel = viewModel(),
    onNextClicked: () -> Unit = {} // 함수형 파라미터로 다음 이동 처리
) {
    val result = viewModel.userResult

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF0F4F8)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 상단 문구
            Text(
                text = "${result.nickname} 님의 프로필이 완성됐어요!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp),
                textAlign = TextAlign.Center
            )

            // 사용자 정보 카드
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "👤 ${result.nickname}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = result.intro,
                        fontSize = 16.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 키워드 제목
            Text(
                text = "✨ 나를 표현하는 키워드 ✨",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(12.dp))

            // 키워드 태그들
            FlowRow(modifier = Modifier.fillMaxWidth()) {
                result.keywords.forEach {
                    ChipContent(it)
                    Spacer(modifier = Modifier.width(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            val context = LocalContext.current
            // 다음 버튼 이미지
            Image(
                painter = painterResource(id = R.drawable.btnlookfor),
                contentDescription = "커뮤니티로 이동",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .width(320.dp)
                    .height(80.dp)
                    .clickable {
                        context.startActivity(Intent(context, CommunityActivity::class.java))
                    }
                    .padding(top = 32.dp)

            )

        }
    }
}

@Composable
fun ChipContent(keyword: String) {
    Surface(
        modifier = Modifier.padding(4.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFFFF5A3E)
    ) {
        Box(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = keyword,
                fontSize = 14.sp,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

