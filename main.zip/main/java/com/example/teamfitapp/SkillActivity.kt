package com.example.teamfitapp

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions


class SkillActivity : AppCompatActivity() {

    private val selectedJobTags = mutableListOf<String>()
    private val selectedStackTags = mutableListOf<String>()

    private lateinit var nextButton: ImageButton
    private lateinit var selectedSummaryText: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skill)

        val nickname = intent.getStringExtra("nickname") ?: "회원"
        val intro = intent.getStringExtra("intro") ?: ""

        selectedSummaryText = findViewById(R.id.selectedSummaryText)
        nextButton = findViewById(R.id.nextButton)


        findViewById<ImageButton>(R.id.jobButton).setOnClickListener {
            JobBottomSheet { selected ->
                selectedJobTags.clear()
                selectedJobTags.addAll(selected)
                updateSummary()
            }.show(supportFragmentManager, "JobSheet")
        }

        findViewById<ImageButton>(R.id.stackButton).setOnClickListener {
            StackBottomSheet { selected ->
                selectedStackTags.clear()
                selectedStackTags.addAll(selected)
                updateSummary()
            }.show(supportFragmentManager, "StackSheet")
        }

        // 클릭 리스너
        nextButton.setOnClickListener {
            if (selectedJobTags.isEmpty() || selectedStackTags.isEmpty()) {
                Toast.makeText(this, "직군과 스택을 모두 선택해주세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            saveSkillInfo(selectedJobTags, selectedStackTags)

            val intent = Intent(this, QuestionActivity::class.java)
            intent.putStringArrayListExtra("jobTags", ArrayList(selectedJobTags))
            intent.putStringArrayListExtra("stackTags", ArrayList(selectedStackTags))
            intent.putExtra("nickname", nickname)
            intent.putExtra("intro", intro)
            startActivity(intent)
        }
    }

    private fun updateSummary() {
        // 선택된 직군 표시
        val jobLabel = findViewById<TextView>(R.id.jobLabel)
        jobLabel.text = "${selectedJobTags.joinToString(", ")}"

        // 선택된 스택 표시
        val stackLabel = findViewById<TextView>(R.id.stackLabel)
        stackLabel.text = "${selectedStackTags.joinToString(", ")}"

        val isReady = selectedJobTags.isNotEmpty() && selectedStackTags.isNotEmpty()

        nextButton.isEnabled = isReady
        nextButton.setImageResource(
            if (isReady) R.drawable.btnnext
            else R.drawable.btnnextdisable
        )

    }

    private fun saveSkillInfo(jobTags: List<String>, stackTags: List<String>) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val userRef = FirebaseFirestore.getInstance().collection("users").document(uid)

        val updateData = mapOf(
            "jobTags" to jobTags,
            "stackTags" to stackTags
        )

        userRef.set(updateData, SetOptions.merge())
            .addOnSuccessListener {
                Toast.makeText(this, "스킬 정보 저장 완료", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "스킬 저장 실패: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
}